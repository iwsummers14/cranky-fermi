﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterOfParts
{
    // child class for inhouse part, inherits abstract class Part
    public class Inhouse : Part
    {
        public int MachineId { get; set; }

    }

}
